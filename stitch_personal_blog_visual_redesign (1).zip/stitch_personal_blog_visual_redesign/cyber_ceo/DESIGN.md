# Design System Strategy: The Digital Architect

## 1. Overview & Creative North Star

This design system is built upon the **"Digital Architect"** Creative North Star. It represents the intersection of executive leadership and technical mastery—where the high-level vision of a CEO meets the precision and "vibe" of a modern developer. 

To break the "template" look common in tech blogs, this system leverages **Intentional Asymmetry** and **Editorial Scale**. We reject the rigid, centered grid in favor of a layout that breathes through expansive white space (using `surface` and `surface-dim`) and bold, high-contrast typography. By overlapping glassmorphic elements and utilizing deep tonal layering, the UI feels like a high-end digital journal rather than a standard CMS.

---

## 2. Colors & Surface Philosophy

The palette is anchored in a sophisticated midnight foundation (`background: #0b0e14`), punctuated by vibrant, "neon-electric" accents that signal technical energy.

*   **The "No-Line" Rule:** To maintain a premium, editorial feel, 1px solid borders are strictly prohibited for sectioning. Structural boundaries must be defined through background shifts. For instance, a main content area using `surface` should transition into a `surface-container-low` section to denote a footer or sidebar.
*   **Surface Hierarchy & Nesting:** Treat the UI as a series of physical layers. Use the `surface-container` tiers to create depth:
    *   **Level 0 (Base):** `surface` (#0b0e14)
    *   **Level 1 (Sections):** `surface-container-low` (#10131a)
    *   **Level 2 (Cards/Interaction):** `surface-container-high` (#1c2028)
*   **The "Glass & Gradient" Rule:** Floating elements (modals, navigation bars) should utilize glassmorphism. Use `surface-container` at 70% opacity with a `20px` backdrop blur. 
*   **Signature Textures:** For high-impact areas like hero buttons or "vibe coding" indicators, use a linear gradient transitioning from `primary` (#9cff93) to `primary-container` (#00fc40).

---

## 3. Typography: The CEO-Coder Bridge

The typography system is a deliberate dialogue between authority (`Inter`) and intellectual curiosity (`Newsreader` & `Space Grotesk`).

*   **Display & Headlines (Inter):** High-end sans-serif used for `display-lg` through `headline-sm`. These should be set with tight letter-spacing (-0.02em) to feel architectural and strong.
*   **The Narrative Body (Newsreader):** To capture the "CEO's Journal" feel, all long-form reading uses a modern serif. This softens the technical edges of the site and improves legibility for long-form thought leadership.
*   **The Technical Label (Space Grotesk):** Metadata, code snippets, and tags use Space Grotesk. This provides a "monospaced-adjacent" look that signals "Coder" without sacrificing the modern aesthetic.

---

## 4. Elevation & Depth

We eschew traditional drop shadows in favor of **Tonal Layering**.

*   **The Layering Principle:** Place a `surface-container-lowest` card on top of a `surface-container-low` background. The shift in hex value provides a natural, soft "lift."
*   **Ambient Shadows:** If an element must float (e.g., a primary CTA), use a shadow tinted with `surface-tint`.
    *   *Shadow Specs:* `0px 20px 40px rgba(156, 255, 147, 0.04)` — subtle, diffused, and colored.
*   **The "Ghost Border" Fallback:** For accessibility in card components, use a `1px` border of `outline-variant` (#45484f) at **20% opacity**. It should be felt, not seen.
*   **Glassmorphism:** Use for persistent navigation. It allows the "vibe" of the content to bleed through, ensuring the UI feels integrated with the "Digital Architect" aesthetic.

---

## 5. Components

### Buttons
*   **Primary:** `primary` background, `on-primary-fixed` text. Roundedness: `md` (0.375rem). No shadow; use a subtle scale-up interaction (1.02x) on hover.
*   **Secondary:** Glassmorphic. Semi-transparent `surface-container-highest` with a `Ghost Border`.
*   **Tertiary:** Text only using `secondary` (#bf81ff) with an underline that appears on hover.

### Cards (The Article Feed)
*   **Styling:** Background of `surface-container-high`. 
*   **Constraint:** **Strictly no divider lines.** Separate the headline from the metadata using a `1.5rem` vertical gap.
*   **Interaction:** On hover, transition the background to `surface-bright` and apply a `primary` glow to the "Ghost Border."

### Chips & Tags
*   **Visual:** Using `label-md` (Space Grotesk). Background: `surface-variant`.
*   **Style:** Pill-shaped (`full` roundedness). These represent the "Coder" side of the brand—clean, functional, and tech-forward.

### Input Fields
*   **Base:** `surface-container-lowest`. 
*   **Focus State:** The `outline` should transition to `tertiary` (#81ecff) with a soft glow effect.

### Code Snippets
*   **Container:** `surface-container-lowest`.
*   **Typography:** `body-sm` (Space Grotesk).
*   **Syntax Highlighting:** Use `primary` for functions, `secondary` for strings, and `tertiary` for variables.

---

## 6. Do's and Don'ts

### Do
*   **DO** use extreme whitespace. If a section feels "tight," double the padding.
*   **DO** mix typography. A `display-lg` sans-serif headline followed by a `title-lg` serif subline is the signature look.
*   **DO** use the `primary` green accent sparingly for maximum impact (e.g., a single word in a headline or a high-value CTA).

### Don't
*   **DON'T** use pure white (#ffffff). Always use `on-surface` (#ecedf6) to reduce eye strain against the dark background.
*   **DON'T** use 100% opaque borders. They break the "Physical Layering" illusion and make the site feel like a legacy bootstrap template.
*   **DON'T** use standard "Material" shadows. If a shadow isn't diffused and tinted, it doesn't belong in this system.