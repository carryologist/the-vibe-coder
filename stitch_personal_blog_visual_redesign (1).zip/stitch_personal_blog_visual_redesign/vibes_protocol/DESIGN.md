# Visual Identity & Design System

## 1. Overview & Creative North Star: "The Neon Brutalist"
This design system is engineered to bridge the gap between high-performance engineering and editorial sophistication. Our Creative North Star is **"The Neon Brutalist."** 

Unlike traditional enterprise software that relies on rigid grids and heavy borders, this system utilizes "Atmospheric Depth." We embrace the starkness of a dark environment (`#090B0B`) and punctuate it with high-energy neon pulses (`#F08DFF`, `#BC7CFF`, `#FF8067`). The experience should feel like a premium terminal interface—high-contrast, precise, and intentionally layered. We break the "template" look through aggressive typographic scales and intentional asymmetry, allowing content to "float" within a structured void.

---

## 2. Colors & Surface Logic

### The "No-Line" Rule
**Explicit Instruction:** 1px solid borders are strictly prohibited for sectioning or layout containment. 
Boundaries are defined exclusively through **Tonal Transitions**. Use the `surface-container` tiers to create hierarchy. A `surface-container-low` section sitting on a `surface` background provides all the separation a user needs without the visual "noise" of a line.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of materials. 
- **Base Layer:** `surface` (#121414)
- **Secondary Logic:** `surface-container-low` (#1a1c1c) for main content areas.
- **Interactive Elements:** `surface-container-high` (#282a2a) for elevated cards or hovered states.
- **Nesting:** When placing a card inside a section, the card should move one tier higher in the `surface-container` scale to create a natural, "lifted" appearance.

### The "Glass & Gradient" Rule
To inject "soul" into the technical layout:
- **Glassmorphism:** Use semi-transparent surface tokens with a `backdrop-blur` (20px–40px) for navigation bars and floating modals.
- **Vibrant Gradients:** Main CTAs and Hero accents should utilize a linear gradient: `primary` (#dcb8ff) → `secondary` (#f7acff) at a 135° angle.

---

## 3. Typography: Editorial Precision
The typographic voice is dual-natured: the Swiss-style authority of **Lay Grotesk** paired with the hyper-technical precision of **FT System Mono**.

*   **Display & Headline (Lay Grotesk / Space Grotesk):** These are your "statement" levels. Use `display-lg` (3.5rem) with tight letter-spacing (-0.02em) to create an authoritative, editorial feel.
*   **Body (Inter / Geist):** Designed for maximum readability. Always use `body-md` (0.875rem) for documentation and long-form text to maintain a sophisticated "pro" density.
*   **Labels (FT System Mono / Space Grotesk):** Use for metadata, tags, and small captions. These should feel like "code outputs"—raw and functional.

---

## 4. Elevation & Depth

### The Layering Principle
Depth is achieved by "stacking" tones. 
*   **Example:** A `surface-container-lowest` card placed on a `surface-container-low` background creates a "sunken" effect. Conversely, `surface-container-highest` on `surface` creates an "elevated" effect.

### Ambient Shadows
Shadows must be "felt, not seen."
*   **Value:** `0px 24px 48px rgba(0, 0, 0, 0.4)`
*   **Tinting:** Shadows are never pure black; they are a 4%–8% opacity version of the `on-surface` color, ensuring they feel integrated into the dark theme.

### The "Ghost Border" Fallback
If accessibility requirements demand a border, use the **Ghost Border**:
*   Token: `outline-variant` (#4c4452) at **15% opacity**. 
*   This creates a "hint" of a boundary that disappears into the background, maintaining the "No-Line" philosophy.

---

## 5. Components

### Buttons
*   **Primary:** A high-gloss gradient of `primary` to `secondary`. Text is `on-primary` (#480081). Radius: `md` (0.375rem).
*   **Secondary:** Ghost style. No fill, `surface-tint` outline at 20% opacity.
*   **Tertiary:** Pure text using `primary` color, strictly for low-priority actions.

### Cards & Lists
*   **Rule:** No dividers. Separate list items using `spacing-sm` (0.5rem) and subtle background shifts on hover (`surface-container-high`).
*   **Interactive Cards:** Should utilize `surface-container-low`. On hover, transition to `surface-container-highest` with a 2px "Neon Glow" (a drop shadow using the `primary` color at 10% opacity).

### Input Fields
*   **State:** Background is `surface-container-lowest`. 
*   **Focus:** The "Ghost Border" becomes 100% opaque `primary` (#dcb8ff) with a 4px soft outer glow.

### Signature Component: The "Vibe" Tag
*   A selection chip using `secondary-container` (#781b8b) with `on-secondary-container` (#f296ff) text. Use `full` rounding (9999px) to contrast against the otherwise geometric, sharp-edged layout.

---

## 6. Do's and Don'ts

### Do:
*   **Embrace Negative Space:** Give display typography room to breathe.
*   **Use Mono for Data:** Any numerical value or system status must use the Mono scale.
*   **Layer Tones:** Use `surface-container` tiers to guide the eye toward the primary action.

### Don't:
*   **Don't use 1px lines:** Do not use borders to separate the header from the body. Use a background color shift instead.
*   **Don't use pure White text:** Use `on-surface` (#e2e2e2) for body text to reduce eye strain and look more premium.
*   **Don't use Standard Shadows:** Never use high-opacity, small-radius shadows. They look "cheap" and break the atmospheric immersion.

### Accessibility Note:
While we use subtle tonal shifts, always ensure that the contrast ratio between text (`on-surface`) and its immediate background (`surface-container-x`) meets WCAG AA standards. If in doubt, increase the `surface-container` tier.